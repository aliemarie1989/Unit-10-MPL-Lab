public class Rock {
    private int sampleNumber;
    private String description;
    private double weightInGrams;

    public Rock(int sampleNumber, double weightInGrams) {
        this.sampleNumber = sampleNumber;
        this.weightInGrams = weightInGrams;
        this.description = "Unclassified";
    }

    public int getSampleNumber() {
        return sampleNumber;
    }

    public String getDescription() {
        return description;
    }

    public double getWeightInGrams() {
        return weightInGrams;
    }
}