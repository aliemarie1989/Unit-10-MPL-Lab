import java.util.Scanner;

public class DemoRocks {
public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    Rock rockSample;

System.out.println("Enter the type of Rock collected (U, I, S, M):");
String rockType = input.nextLine().toUpperCase();

    if (rockType.equals("U") || rockType.equals("I") || rockType.equals("S") || rockType.equals("M")) {
System.out.println("Enter the sample number:");
    int sampleNumber = input.nextInt();
System.out.println("Enter the weight of the rock in grams:");
    double weight = input.nextDouble();
    input.nextLine(); // Consume the newline charac.

switch (rockType) {
    case "I":
    rockSample = new IgneousRock(sampleNumber, weight);
    break;
    case "S":
rockSample = new SedimentaryRock(sampleNumber, weight);
    break;
    case "M":
    rockSample = new MetamorphicRock(sampleNumber, weight);
    break;
    default: // case U
    rockSample = new Rock(sampleNumber, weight);
    break;
}
} else {
            rockSample = new Rock(0, 0);
        }

        displayRockDetails(rockSample);
        input.close();
    }

    public static void displayRockDetails(Rock rock) {
        System.out.println("\nRock Details:");
        System.out.println("Sample Number: " + rock.getSampleNumber());
        System.out.println("Description: " + rock.getDescription());
        System.out.println("Weight (grams): " + rock.getWeightInGrams());
    }
}