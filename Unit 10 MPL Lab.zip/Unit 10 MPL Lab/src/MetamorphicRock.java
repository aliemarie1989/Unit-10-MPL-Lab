public class MetamorphicRock extends Rock {
public MetamorphicRock(int sampleNumber, double weightInGrams) {
super(sampleNumber, weightInGrams);
setDescription("Metamorphic rocks arise from the transformation"
        + " of existing rock to new types of rock, in a process called metamorphism,"
        + " due to heat, pressure, or chemical reactions.");
    }
}
