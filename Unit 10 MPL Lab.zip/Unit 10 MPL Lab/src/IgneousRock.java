public class IgneousRock extends Rock {
public IgneousRock(int sampleNumber, double weightInGrams) {
super(sampleNumber, weightInGrams);
setDescription("Igneous rocks are formed through the cooling"
        + " and solidification of magma or lava.");
    }
}