public class SedimentaryRock extends Rock {
public SedimentaryRock(int sampleNumber, double weightInGrams) {
super(sampleNumber, weightInGrams);
setDescription("Sedimentary rocks are formed from the accumulation"
        + " or deposition of mineral or organic particles at Earth's "
        + "surface, followed by cementation.");
    }
}
